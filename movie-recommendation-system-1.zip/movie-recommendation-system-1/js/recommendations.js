// Array of movie recommendations
const movieRecommendations = [
  { 
    title: "Avengers: Endgame", 
    year: 1994, 
    genre: "Drama", 
    rating: 9.3, 
    poster: "assest/images/section2/img1.jpg", 
    imdbLink: "https://www.imdb.com/title/tt4154796/" 
  },
  { 
    title: "The Dark Knight", 
    year: 2008, 
    genre: "Action", 
    rating: 9.0, 
    poster: "assest/images/section2/img2.jpg", 
    imdbLink: "https://www.imdb.com/title/tt0468569/" 
  },
  { 
    title: "Spider-Man: No Way Home", 
    year: 2010, 
    genre: "Sci-Fi", 
    rating: 8.8, 
    poster: "assest/images/section2/img3.jpg", 
    imdbLink: "https://www.imdb.com/title/tt10872600/" 
  },
  { 
    title: "Avatar 2", 
    year: 1994, 
    genre: "Drama", 
    rating: 8.8, 
    poster: "assest/images/section2/img4.jpg", 
    imdbLink: "https://www.imdb.com/title/tt1630029/" 
  },
  { 
    title: "The Witcher", 
    year: 1999, 
    genre: "Sci-Fi", 
    rating: 8.7, 
    poster: "assest/images/section2/img5.jpg", 
    imdbLink: "https://www.imdb.com/title/tt4881806/" 
  },
  { 
    title: "Stranger Things", 
    year: 1997, 
    genre: "Romance", 
    rating: 7.8, 
    poster: "assest/images/section2/img6.jpg", 
    imdbLink: "https://www.imdb.com/title/tt4574334/" 
  }
];

// Function to display movie recommendations in cards
function displayRecommendations(recommendations) {
  const recommendationsSection = document.getElementById("recommendations-list");
  recommendationsSection.innerHTML = ""; // Clear previous recommendations

  // Loop through the movie recommendations and create HTML for each movie
  recommendations.forEach(movie => {
    const movieElement = document.createElement("div");
    movieElement.classList.add("movie-card");
    
    movieElement.innerHTML = `
      <img src="${movie.poster}" alt="${movie.title}" class="movie-poster">
      <h3>${movie.title}</h3>
      <p>Year: ${movie.year}</p>
      <p>Genre: ${movie.genre}</p>
      <p>Rating: ${movie.rating}</p>
      <a href="${movie.imdbLink}" target="_blank" class="btn-secondary">View on IMDb</a>
    `;
    
    recommendationsSection.appendChild(movieElement);
  });
}

// Function to filter movies by genre
function filterByGenre(genre) {
  const filteredMovies = movieRecommendations.filter(movie => movie.genre === genre);
  displayRecommendations(filteredMovies);
}

// Function to sort movies by rating
function sortByRating() {
  const sortedMovies = [...movieRecommendations].sort((a, b) => b.rating - a.rating);
  displayRecommendations(sortedMovies);
}

// Function to handle user input and filter movies
document.getElementById("genre-filter").addEventListener("change", function(event) {
  const selectedGenre = event.target.value;
  if (selectedGenre === "All") {
    displayRecommendations(movieRecommendations); // Show all movies if "All" is selected
  } else {
    filterByGenre(selectedGenre);
  }
});

// Event listener to sort movies by rating when a button is clicked
document.getElementById("sort-rating").addEventListener("click", function() {
  sortByRating();
});

// Initialize the page with all movie recommendations
window.onload = function() {
  displayRecommendations(movieRecommendations);
};
