// Example movie recommendations (can later be fetched from an API or backend)
const movieRecommendations = [
    { title: "The Shawshank Redemption", year: 1994, genre: "Drama", poster: "assets/images/shawshank.jpg" },
    { title: "The Dark Knight", year: 2008, genre: "Action", poster: "assets/images/dark-knight.jpg" },
    { title: "Inception", year: 2010, genre: "Sci-Fi", poster: "assets/images/inception.jpg" },
    { title: "Forrest Gump", year: 1994, genre: "Drama", poster: "assets/images/forrest-gump.jpg" },
    { title: "The Matrix", year: 1999, genre: "Sci-Fi", poster: "assets/images/matrix.jpg" }
  ];
  
  // Function to display movie recommendations
  function displayRecommendations() {
    const recommendationsSection = document.getElementById("recommendations-list");
    
    // Loop through the movie recommendations and create HTML for each movie
    movieRecommendations.forEach(movie => {
      const movieElement = document.createElement("div");
      movieElement.classList.add("movie-item");
      
      movieElement.innerHTML = `
        <img src="${movie.poster}" alt="${movie.title}" class="movie-poster">
        <h3 class="movie-title">${movie.title}</h3>
        <p class="movie-year">${movie.year}</p>
        <p class="movie-genre">${movie.genre}</p>
      `;
      
      recommendationsSection.appendChild(movieElement);
    });
  }
  
  // Call displayRecommendations when the page loads
  window.onload = function() {
    displayRecommendations();
  };
  
  // Simple form submission for "Contact" page (for example)
  document.getElementById("contact-form").addEventListener("submit", function(event) {
    event.preventDefault();
    
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;
    
    // Display a simple confirmation message
    alert(`Thank you, ${name}! Your message has been sent.`);
    
    // Optionally, you could send this data to a server or an API for processing
    console.log("Contact form submitted:", { name, email, message });
  });
  
  // Toggle visibility of the "About" section (just an example for interactive behavior)
  document.getElementById("toggle-about").addEventListener("click", function() {
    const aboutSection = document.getElementById("about");
    aboutSection.style.display = (aboutSection.style.display === "none") ? "block" : "none";
  });
  